print("Welcome to the POTATOSCRIPT SHELL. Type help for help (version 1).")

cmd = ""

while cmd != "esc":
    cmd = input("AOST/CYPOT/potatoshell/: ")