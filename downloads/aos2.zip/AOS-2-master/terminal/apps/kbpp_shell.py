print("This is the K-BALL++ SHELL. Type help for help.")

cmd = ""

while cmd != "esc":
    cmd = input("AOST/SCR/shell/: ")
    if cmd == "help":
        print("List of all commands:\n")
        print(".speak")
