Unzip yaspin.zip inside the modules folder for the yaspin module to work properly

( I compressed it because GitHub kept on telling me I had too many files )